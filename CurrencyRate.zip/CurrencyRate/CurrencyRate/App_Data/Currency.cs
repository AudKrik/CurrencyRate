﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Mvc;
using System.Xml.Serialization;

namespace Currency
{
    public class Item
    {
        private string _rate; // Private variable _rate to store XML string

        // Property that exposes currency name as string
        [XmlElement("currency", IsNullable = true)]
        public string currency { get; set; }

        // Property that exposes rate of curency. Specifying the type forces
        // the serializer to return the value as a string.
        [XmlElement("rate", Type = typeof(string))]
        public object rate
        {
            get
            {
                return
                    !string.IsNullOrEmpty(_rate) ?
                (Decimal?)Convert.ToDecimal(_rate, new NumberFormatInfo { NumberDecimalSeparator = "." }) :
                    null;
            }
            set { _rate = (string)value; }
        }
    }

    // Property that exposes ExchangeRates as a class of item list
    [XmlRoot("ExchangeRates")]
    public class ExchangeRates
    {
        [XmlElement("item", typeof(Item))]
        public List<Item> ItemList { get; set; }
    }
}