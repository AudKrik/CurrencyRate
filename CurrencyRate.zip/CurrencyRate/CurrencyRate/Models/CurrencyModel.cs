﻿using CurrencyRate.ValidationAttributes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CurrencyRate.Models
{
    // Model class for items used to form a list ListCurrencies
    public class CurrencyItem 
    {
        public string currency { get; set; }
        public decimal rate { get; set; }
        public decimal rateDiff { get; set; }
    }

    // Main model used to select date and return object list for representation.
    // Page size stand for quantity for items beeing shown in WebGrid
    public class CurrencyModel
    {
        [Display(Name = "Select date:")]
        [DataType(DataType.Date)]
        [ValidDate(ErrorMessage = "Data exsists up to the end of years 2014 only")]
        public DateTime? searchDate { get; set; }
        public int PageSize { get; set; }
        public List<CurrencyItem> ListCurrencies { get; set; } // List represented in main's view WebGrid table
     
    }
}