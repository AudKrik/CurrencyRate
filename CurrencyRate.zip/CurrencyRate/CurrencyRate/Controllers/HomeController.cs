﻿using System;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web.Mvc;
using Currency;
using System.Xml.Serialization;
using CurrencyRate.Models;
using System.Collections.Generic;

namespace CurrencyRate.Controllers
{
    public class HomeController : Controller // Main controller for actions and additional methods
    {

        // Main action to represent stating view. If data is selected gets data for date
        // specified from public service, fills model and sends it to the same view.
        [OutputCache(Duration = int.MaxValue, VaryByParam = "searchDate")] // Caches the data for specified date.
        public ActionResult Index(DateTime? searchDate, CurrencyModel model)
        {
            if (ModelState.IsValid)
            {
                if (searchDate != null)
                {
                    model = new CurrencyModel();

                    List<Item> CurrentDateList = GetList((DateTime)searchDate);
                    List<Item> PreviuosDateList = GetList(((DateTime)searchDate).AddDays(-1));
                    if (CurrentDateList == null || PreviuosDateList == null)
                        return View("Error");

                    List<CurrencyItem> result = CombineLists(CurrentDateList, PreviuosDateList);
                    model.PageSize = result.Count();
                    model.ListCurrencies = result.OrderByDescending(r => r.rateDiff).ToList();
                    model.searchDate = searchDate;

                    return View(model);
                }
            }
            return View();
        }

        // Creates new list from current date list of curiencies data and the other - from the day before date.
        // Knowing that elements, got form service size and order stays the same, fast approach with for iteration
        // of generating main list is implemented.
        public List<CurrencyItem> CombineLists(List<Item> CurrentDateList, List<Item> PreviuosDateList)
        {
            List<CurrencyItem> MergedList = new List<CurrencyItem>();
            for (int i = 0; i < CurrentDateList.Count(); i++)
            {
                CurrencyItem currentItem = new CurrencyItem
                {
                    currency = CurrentDateList[i].currency,
                    rate = Convert.ToDecimal(CurrentDateList[i].rate),
                    rateDiff = decimal.Round(((100 * (decimal)PreviuosDateList[i].rate) / ((decimal)CurrentDateList[i].rate) - 100), 4, MidpointRounding.AwayFromZero)
                };
                MergedList.Add(currentItem);
            }
            return MergedList;
        }

        // Get request with date parameter is send to public service. Deserialization and serialization is made for request return
        // to generate list of objects
        public List<Item> GetList(DateTime date)
        {
            ExchangeRates result = null;
            try
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://www.lb.lt");
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("text/xml"));
                    var response = client.GetAsync("/webservices/ExchangeRates/ExchangeRates.asmx/getExchangeRatesByDate?Date=" + date.ToString()).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        string responseString = response.Content.ReadAsStringAsync().Result;
                        result = (ExchangeRates)(new XmlSerializer(typeof(ExchangeRates)).Deserialize(new System.IO.StringReader(responseString)));
                    }
                }
                return result.ItemList;
            }
            catch (Exception x)
            {
                Console.WriteLine("Error while getting data:" + x);
                return null;
            }

        }

        //Opens a document with brief information about application
        public ActionResult About()
        {
            return File("~/Content/Documentation.docx", "application/ms-word", Server.UrlEncode("Documentation.docx"));
        }
    }
}