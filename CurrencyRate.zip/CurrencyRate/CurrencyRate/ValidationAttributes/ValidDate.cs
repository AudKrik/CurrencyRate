﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace CurrencyRate.ValidationAttributes
{
    // Helper class for custom date parameter valiadation with condition <= 2014 years
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public sealed class ValidDate : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value != null)
            {
                DateTime date = Convert.ToDateTime(value);
                if (date >= DateTime.Now.Date.AddYears(-3))
                {
                    return new ValidationResult("Data exsists up to the end of years 2014 only");
                }
            }
            return ValidationResult.Success;
        }
    }
}